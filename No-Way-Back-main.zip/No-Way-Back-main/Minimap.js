import { Transform } from './Transform.js';

export class Minimap {
    constructor(options = {}) {
    this.canvas = document.createElement('canvas');
    this.ctx = this.canvas.getContext('2d');
    
    this.size = options.size || 300; 
    this.worldSize = options.worldSize || 60;
    this.canvas.width = this.size;
    this.canvas.height = this.size;
    
    // FORCE VISIBILITY STYLES
    Object.assign(this.canvas.style, {
            position: 'fixed',
            bottom: '30px',
            right: '30px',
            width: this.size + 'px',
            height: this.size + 'px',
            border: '2px solid white', // Changed from pink to white
            borderRadius: '8px',
            backgroundColor: 'rgba(0, 0, 0, 0.7)',
            zIndex: '10000',
            pointerEvents: 'none',
            display: 'block'             // Ensure it's not hidden
        });

    // Make sure it's added to the document
    document.body.appendChild(this.canvas);
    console.log("Minimap canvas appended to body"); 

    this.playerNode = options.playerNode;
    this.walls = options.walls || [];
    this.monkeys = options.monkeys || [];
    this.shards = options.shards || [];
}

    // Inside Minimap.js

_worldToMap(x, z) {
    // floorSize is 60. If your world range is -30 to 30:
    // We add (worldSize / 2) to shift -30 into 0.
    const centerX = x + (this.worldSize / 2);
    const centerZ = z + (this.worldSize / 2);

    // Now scale those 0-60 values to the 0-200px canvas size
    const mapX = (centerX / this.worldSize) * this.size;
    const mapY = (centerZ / this.worldSize) * this.size;

    return { x: mapX, y: mapY };
}

update() {
    this.ctx.clearRect(0, 0, this.size, this.size);

    // 1. Draw Walls
    this.ctx.strokeStyle = 'white';
    this.ctx.lineWidth = 1;
    this.walls.forEach(wall => {
        // Use the pos from your Positions.js
        const p = this._worldToMap(wall.pos[0], wall.pos[2]);
        
        // Scale the wall dimensions to map pixels
        const w = (wall.size[0] / this.worldSize) * this.size;
        const h = (wall.size[2] / this.worldSize) * this.size;

        // Draw the wall centered on its position
        this.ctx.strokeRect(p.x - w/2, p.y - h/2, w, h);
    });

    // 2. Draw Shards (Green)
    this.ctx.fillStyle = '#00ff00';
    this.shards.forEach(shard => {
        const t = shard.node.getComponentOfType(Transform);
        if (t) {
            const p = this._worldToMap(t.translation[0], t.translation[2]);
            this.ctx.beginPath();
            this.ctx.arc(p.x, p.y, 3, 0, Math.PI * 2);
            this.ctx.fill();
        }
    });

    // 3. Draw Player (Yellow)
    if (this.playerNode) {
        const t = this.playerNode.getComponentOfType(Transform);
        if (t) {
            const p = this._worldToMap(t.translation[0], t.translation[2]);
            this.ctx.fillStyle = 'yellow';
            this.ctx.beginPath();
            this.ctx.arc(p.x, p.y, 4, 0, Math.PI * 2);
            this.ctx.fill();
        }
    }
    // 4. Draw Monkey (Red)
        this.ctx.fillStyle = '#ff0000';
        this.monkeys.forEach(m => {
            // Attempt to get transform from m.node or m directly
            const node = m.node || m; 
            const t = node.getComponentOfType ? node.getComponentOfType(Transform) : null;
            if (t) {
                const p = this._worldToMap(t.translation[0], t.translation[2]);
                this.ctx.beginPath();
                this.ctx.arc(p.x, p.y, 5, 0, Math.PI * 2);
                this.ctx.fill();
            }
        });
}
}
