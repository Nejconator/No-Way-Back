import { quat, mat4, vec3 } from './glm.js';
import { Transform } from './Transform.js';
import { Camera } from './Camera.js';
import { Node } from './Node.js';
import { Wall } from './wall.js';
import { monkey } from './monkey.js';
import { Collisions } from './Collisions.js';
import { floorSize, walls } from './Positions.js';
import { corners } from './corner.js';
import { Shard } from './shard.js';
import { UNIFORM_BYTES, buildUniformData, lightingState } from "./Lighting.js";
import { Door } from './doors.js';
import {
    getGlobalModelMatrix,
    getGlobalViewMatrix,
    getProjectionMatrix,
} from './SceneUtils.js';



// Initialize WebGPU
const adapter = await navigator.gpu.requestAdapter();
const device = await adapter.requestDevice();
const canvas = document.querySelector('canvas');
canvas.width = window.innerWidth * devicePixelRatio;
canvas.height = window.innerHeight * devicePixelRatio;
const context = canvas.getContext('webgpu');
const format = navigator.gpu.getPreferredCanvasFormat();
context.configure({
    device,
    format,
    size: [canvas.width, canvas.height],
});
await Wall.loadTexture(device);
await monkey.loadTexture(device);
await Shard.loadTexture(device);
await Door.loadTexture(device);



const cornerCordinates = [
    [0,5,0],        //0
    [-2,5,-5],      //1
    [-10,5,-5],     //2
    [-10,5,11],     //3
    [-16,5,11],     //4
    [-22,5,11],     //5
    [-22,5,-9],     //6
    [-28,5,-9],     //7
    [-28,5,-17],    //8
    [-28,5,-28],    //9
    [-2,5,-28],     //10
    [-2,5,-17],     //11
    [28,5,-28],     //12
    [28,5,-13],     //13
    [12,5,-13],     //14
    [12,5,-5],      //15
    [12,5,2],       //16
    [24,5,2],       //17
    [24,5,20],      //18
    [12,5,20],      //19
    [12,5,28],      //20
    [-16,5,28],     //21
    [2,5,20],       //22
    [2,5,11],       //23
    [12,5,11],      //24
    [0,5,-5],       //25
    [],             //player 
]

const Corners = [];
let j=0;
for(const c of corners){
    Corners[j] = [];
    Corners[j][0]=c.c1;
    Corners[j][1]=c.c2;
    Corners[j][2]=c.c3;
    Corners[j][3]=c.c4;
    j++;
}

let shardPositions = [
    [-28,2.5,-28],
    [-24,2.5,-28],
    [-20,2.5,-28],
    [-16,2.5,-28],
    [-12,2.5,-28],
    [-8,2.5,-28],
    [-4,2.5,-28],
    [0,2.5,-28],
    [4,2.5,-28],
    [8,2.5,-28],
    [12,2.5,-28],
    [16,2.5,-28],
    [20,2.5,-28],
    [24,2.5,-28],
    [28,2.5,-28],
    [-28,2.5,-24],
    [-28,2.5,-20],
    [-28,2.5,-16],
    [-28,2.5,-12],
    [-22,2.5,-9],
    [-22,2.5,-5],
    [-22,2.5,-1],
    [-22,2.5,3],
    [-22,2.5,7],
    [-22,2.5,11],
    [-18,2.5,11],
    [-14,2.5,11],
    [-10,2.5,11],
    [-6,2.5,11],
    [-2,2.5,11],
    [2,2.5,11],
    [6,2.5,11],
    [10,2.5,11],
    [-16,2.5,15],
    [-16,2.5,19],
    [-16,2.5,23],
    [-16,2.5,28],
    [-12,2.5,28],
    [-8,2.5,28],
    [-4,2.5,28],
    [0,2.5,28],
    [4,2.5,28],
    [8,2.5,28],
    [12,2.5,28],
    [12,2.5,24],
    [2,2.5,20],
    [6,2.5,20],
    [10,2.5,20],
    [14,2.5,20],
    [18,2.5,20],
    [24,2.5,20],
    [24,2.5,16],
    [24,2.5,12],
    [24,2.5,6],
    [24,2.5,2],
    [20,2.5,2],
    [16,2.5,2],
    [12,2.5,2],
    [12,2.5,-2],
    [12,2.5,-7],
    [12,2.5,-2],
    [12,2.5,-5],
    [12,2.5,-9],
    [12,2.5,-13],
    [16,2.5,-13],
    [20,2.5,-13],
    [24,2.5,-13],
    [28,2.5,-13],
    [28,2.5,-17],
    [28,2.5,-21],
    [28,2.5,-25],
    [-2,2.5,-24],
    [-2,2.5,-20],
    [-2,2.5,-16],
    [-2,2.5,-12],
    [-2,2.5,-8],
    [-2,2.5,-5],
    [-22,2.5,-17],
    [-18,2.5,-17],
    [-14,2.5,-17],
    [-10,2.5,-17],
    [-6,2.5,-17],
    [-10,2.5,-5],
    [-10,2.5,-1],
    [-10,2.5,3],
    [-10,2.5,7],
    [2,2.5,16],
    
];

const shardNum = 15;
let shardsCollected = 0;
const hud = document.getElementById("hud");

const shards = [];
let k=0;
while(k<shardNum){
    const Index = Math.floor(Math.random() * shardPositions.length);
    shards[k] = [];
    shards[k][0] = shardPositions[Index];
    shards[k][1] = true;
    shardPositions.splice(Index, 1);
    k++;
}

const repeatU = 30 / 2.5 ;
const repeatV = 30 / 2.5 ;

// Create vertex buffer
const vertex = new Float32Array([
// positions            //texcoords         
    -30, 0, -30,  1,     0, 0,  // 0 - spredaj levo (zelena trava)
     30, 0, -30,  1,     repeatU, 0,  // 1 - spredaj desno
    -30, 0,  30,  1,     0, repeatV,  // 2 - zadaj levo (temnejša)
     30, 0,  30,  1,     repeatU, repeatV,  // 3 - zadaj desno
]);



// === CEILING (strop) ===
const CEILING_Y = 10.0; // wall.js ima zidove do y=10, zato strop na 10 (lahko 10.2 če želiš)

// Uporabi isti repeat kot floor (da se tekstura tile-a)
const ceilingVertex = new Float32Array([
  // positions              // texcoords
  -30, CEILING_Y, -30,  1,   0, 0,
   30, CEILING_Y, -30,  1,   repeatU, 0,
  -30, CEILING_Y,  30,  1,   0, repeatV,
   30, CEILING_Y,  30,  1,   repeatU, repeatV,
]);

const ceilingVertexBuffer = device.createBuffer({
  size: ceilingVertex.byteLength,
  usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST,
});

device.queue.writeBuffer(ceilingVertexBuffer, 0, ceilingVertex);




const imageBitmap = await fetch('Red-carpet.jpg')
.then(response => response.blob())
.then(blob => createImageBitmap(blob));

const texture = device.createTexture({
    size: [imageBitmap.width, imageBitmap.height],
    format: 'rgba8unorm',
    usage:
        GPUTextureUsage.TEXTURE_BINDING |
        GPUTextureUsage.RENDER_ATTACHMENT |
        GPUTextureUsage.COPY_DST,
});

device.queue.copyExternalImageToTexture(
    { source: imageBitmap },
    { texture },
    [imageBitmap.width, imageBitmap.height]);

    const sampler = device.createSampler({
        addressModeU: 'repeat',
        addressModeV: 'repeat',
        magFilter: "linear",
        minFilter: "linear",
    });

const vertexBuffer = device.createBuffer({
    size: vertex.byteLength,
    usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST,
});

device.queue.writeBuffer(vertexBuffer, 0, vertex);


// naloži ceiling bitmap (lahko je pred pipeline)
const ceilingBitmap = await fetch('ceiling.jpg') // ali ciling.jpg
  .then(r => r.blob())
  .then(b => createImageBitmap(b));

const ceilingTexture = device.createTexture({
  size: [ceilingBitmap.width, ceilingBitmap.height],
  format: 'rgba8unorm',
  usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.COPY_DST,
});

device.queue.copyExternalImageToTexture(
  { source: ceilingBitmap },
  { texture: ceilingTexture },
  [ceilingBitmap.width, ceilingBitmap.height]
);



// Create index buffer
const indices = new Uint32Array([
    0, 1, 2,    // Prvi trikotnik
    2, 1, 3,    // Drugi trikotnik
]);

const indexBuffer = device.createBuffer({
    size: indices.byteLength,
    usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST,
});

device.queue.writeBuffer(indexBuffer, 0, indices);


// Create the depth texture
const depthTexture = device.createTexture({
    size: [canvas.width, canvas.height],
    format: 'depth24plus',
    usage: GPUTextureUsage.RENDER_ATTACHMENT,
});

// Fetch and compile shaders
const code = await fetch('shader.wgsl').then(response => response.text());
const module = device.createShaderModule({ code });

// Create the pipeline
const vertexBufferLayout = {
    arrayStride: 24,
     attributes: [
        {
            shaderLocation: 0,
            offset: 0,
            format: 'float32x4',
        },
        {
            shaderLocation: 1,
            offset: 16,
            format: 'float32x2',
        },
    ],
};

const pipeline = device.createRenderPipeline({
    vertex: {
        module,
        buffers: [vertexBufferLayout],
    },
    fragment: {
        module,
        targets: [{ format }],
    },
    depthStencil: {
        depthWriteEnabled: true,
        depthCompare: 'less',
        format: 'depth24plus',
    },
    primitive: {
        topology: 'triangle-list',
        cullMode: 'none',
    },
    layout: 'auto',
});


//  for ground 

const uniformBuffer = device.createBuffer({
    size: UNIFORM_BYTES,
    usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
});

// ceiling bind group (ZDAJ je pipeline že definiran)
const ceilingBindGroup = device.createBindGroup({
  layout: pipeline.getBindGroupLayout(0),
  entries: [
    { binding: 0, resource: { buffer: uniformBuffer } },
    { binding: 1, resource: ceilingTexture.createView() },
    { binding: 2, resource: sampler },
  ],
});

// Create the bind group for texture
const bindGroup = device.createBindGroup({
    layout: pipeline.getBindGroupLayout(0),
    entries: [
        { binding: 0, resource: { buffer: uniformBuffer } },
        { binding: 1, resource: texture.createView() },
        { binding: 2, resource: sampler },
    ]
});


const lampSize = 0.5;            // širina/višina lampice (x,z)
const lampHeight = 0.25;         // debelina (y)

const lamps = [
    { pos: [0, 9.8, 0], color: [1.0, 0.75, 0.35, 1.0] },
    { pos: [-28, 9.8, -28], color: [1.0, 0.75, 0.35, 1.0] },
    { pos: [-2, 9.8, -28], color: [1.0, 0.75, 0.35, 1.0] },
    { pos: [28, 9.8, -28], color: [1.0, 0.75, 0.35, 1.0] },
    { pos: [-15, 9.8, -17], color: [1.0, 0.75, 0.35, 1.0] },
    { pos: [28, 9.8, -13], color: [1.0, 0.75, 0.35, 1.0] },
    { pos: [-25, 9.8, -9], color: [1.0, 0.75, 0.35, 1.0] },
    { pos: [12, 9.8, -5], color: [1.0, 0.75, 0.35, 1.0] },
    { pos: [24, 9.8, 2], color: [1.0, 0.75, 0.35, 1.0] },
    { pos: [-22, 9.8, 11], color: [1.0, 0.75, 0.35, 1.0] },
    { pos: [-10, 9.8, 3], color: [1.0, 0.75, 0.35, 1.0] },
    { pos: [2, 9.8, 11], color: [1.0, 0.75, 0.35, 1.0] },
    { pos: [24, 9.8, 20], color: [1.0, 0.75, 0.35, 1.0] },
    { pos: [-16, 9.8, 28], color: [1.0, 0.75, 0.35, 1.0] },
    { pos: [-2, 9.8, 28], color: [1.0, 0.75, 0.35, 1.0] },
    { pos: [12, 9.8, 28], color: [1.0, 0.75, 0.35, 1.0] },
];

function createBoxMesh(device) {
  // 24 vertexov (4 na vsako stranico), 36 indeksov
  // Box od -0.5..0.5 po X,Z in -0.5..0.5 po Y
  const v = new Float32Array([
    // +Y (top)
    -0.5,  0.5, -0.5, 1,  0,0,
     0.5,  0.5, -0.5, 1,  1,0,
     0.5,  0.5,  0.5, 1,  1,1,
    -0.5,  0.5,  0.5, 1,  0,1,

    // -Y (bottom)
    -0.5, -0.5,  0.5, 1,  0,0,
     0.5, -0.5,  0.5, 1,  1,0,
     0.5, -0.5, -0.5, 1,  1,1,
    -0.5, -0.5, -0.5, 1,  0,1,

    // +Z (front)
    -0.5, -0.5,  0.5, 1,  0,0,
     0.5, -0.5,  0.5, 1,  1,0,
     0.5,  0.5,  0.5, 1,  1,1,
    -0.5,  0.5,  0.5, 1,  0,1,

    // -Z (back)
     0.5, -0.5, -0.5, 1,  0,0,
    -0.5, -0.5, -0.5, 1,  1,0,
    -0.5,  0.5, -0.5, 1,  1,1,
     0.5,  0.5, -0.5, 1,  0,1,

    // +X (right)
     0.5, -0.5,  0.5, 1,  0,0,
     0.5, -0.5, -0.5, 1,  1,0,
     0.5,  0.5, -0.5, 1,  1,1,
     0.5,  0.5,  0.5, 1,  0,1,

    // -X (left)
    -0.5, -0.5, -0.5, 1,  0,0,
    -0.5, -0.5,  0.5, 1,  1,0,
    -0.5,  0.5,  0.5, 1,  1,1,
    -0.5,  0.5, -0.5, 1,  0,1,
  ]);

  const idx = new Uint16Array([
    0,1,2,  0,2,3,        // top
    4,5,6,  4,6,7,        // bottom
    8,9,10, 8,10,11,      // front
    12,13,14, 12,14,15,   // back
    16,17,18, 16,18,19,   // right
    20,21,22, 20,22,23,   // left
  ]);

  const vertexBuffer = device.createBuffer({
    size: v.byteLength,
    usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST,
    mappedAtCreation: true,
  });
  new Float32Array(vertexBuffer.getMappedRange()).set(v);
  vertexBuffer.unmap();

  const indexBuffer = device.createBuffer({
    size: idx.byteLength,
    usage: GPUBufferUsage.INDEX | GPUBufferUsage.COPY_DST,
    mappedAtCreation: true,
  });
  new Uint16Array(indexBuffer.getMappedRange()).set(idx);
  indexBuffer.unmap();

  return { vertexBuffer, indexBuffer, indexCount: idx.length };
}
const lampMesh = createBoxMesh(device);

const lampCode = await fetch("lampShader.wgsl").then(r => r.text());
const lampModule = device.createShaderModule({ code: lampCode });

const lampPipeline = device.createRenderPipeline({
  layout: "auto",
  vertex: {
    module: lampModule,
    entryPoint: "vertex",
    buffers: [{
      arrayStride: 6 * 4, // x,y,z,w,u,v (uv je sicer ignoriran)
      attributes: [
        { shaderLocation: 0, offset: 0, format: "float32x4" },
      ],
    }],
  },
  fragment: {
    module: lampModule,
    entryPoint: "fragment",
    targets: [{ format }],
  },
  primitive: {
    topology: "triangle-list",
    cullMode: "none",
  },
  depthStencil: {
    depthWriteEnabled: true,
    depthCompare: "less",
    format: "depth24plus",
  },
});

// Uniform: mat4 (64) + vec4 (16) = 80 bajtov
const lampUniformBuffers = lamps.map(() =>
  device.createBuffer({
    size: 80,
    usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST,
  })
);

const lampBindGroups = lampUniformBuffers.map(buf =>
  device.createBindGroup({
    layout: lampPipeline.getBindGroupLayout(0),
    entries: [{ binding: 0, resource: { buffer: buf } }],
  })
);



// Create the scene


const ground = new Node();
ground.addComponent(new Transform());  // Ground is at origin

const camera = new Node();
camera.addComponent(new Camera({
    fovy: 1.5,
    aspect: 1,
}));
camera.addComponent(new Transform({
    translation: [0, 6.5, 0] //6
}));

let cameraDeafultZ = camera.getComponentOfType(Transform).translation[1];

/*
const wall1 = new Wall(device, pipeline, camera, [30, 0, 0], 1, 30);
const wall2 = new Wall(device, pipeline, camera, [-30, 0, 0], 1, 30); 
const wall3 = new Wall(device, pipeline, camera, [0, 0, -30], 0, 30);
const wall4 = new Wall(device, pipeline, camera, [-15, 0, 0], 1, 15);
*/

const Monkey = new monkey(device,pipeline,camera, [2,5,20]);

const shard = new Shard(device, pipeline, camera, [0,2.5,6]);

const door = new Door(device, pipeline, camera, [-0.75,0,4]);
const door2 = new Door(device, pipeline, camera, [0.75,0,4]);


const shrdArray = [];
for (let k = 0; k < shards.length; k++) {
    shrdArray[k] = new Shard(device, pipeline, camera, shards[k][0]);
}


const wallsArray = []; 
let i = 0;
for (const w of walls) {
    if(w.rotation === 0){
    wallsArray[i] = new Wall(device, pipeline, camera, w.pos, w.rotation, w.size[0]/2);
    }
    if(w.rotation === 1){
        wallsArray[i] = new Wall(device, pipeline, camera, w.pos, w.rotation, w.size[2]/2);
    }
    i++;
}


// računaš točo eno mersko enoto pred tabo v smeri kamere
function getForwardVector(camera) {
    const world = getGlobalModelMatrix(camera);
    
    const forward = [-world[8], -world[9], -world[10]];
    const backward = [world[8], world[9], world[10]];
    
    const len = Math.hypot(forward[0], forward[1], forward[2]);
    forward[0] /= len; 
    forward[1] /= len; 
    forward[2] /= len;

    const ForwardPosition = camera.getComponentOfType(Transform).translation;
    const FrPosition = [ForwardPosition[0] + forward[0],
                        ForwardPosition[1] + forward[1],
                        ForwardPosition[2] + forward[2]];
    
    return FrPosition;
}

function AngleBetweenVectors(v1, v2) {
    let dot = vec3.dot(v1, v2);
    let mag = vec3.length(v1) * vec3.length(v2);
    let angleBetween = Math.acos(dot / mag);


    let cross = vec3.cross([], v1, v2);
    if (cross[1] < 0) {
        angleBetween = -angleBetween;
    }
    return angleBetween;
}

function VectLenght(vect){
    return Math.sqrt(vect[0]*vect[0] + vect[1]*vect[1] + vect[2]*vect[2]);
}

// nastavitve za premikanje ----------------------------------------------------------
const cameraSpeed = 0.1;
const keysPressed = {};
const sensitivity = 0.002;

let MouseX = 0;
let MouseY = 0;


canvas.addEventListener('click', () => {
    canvas.requestPointerLock();
});

window.addEventListener('mousemove', (e) => {
    MouseX += e.movementX;
    MouseY += e.movementY;
});

let dooropened = false;

let velocityW = 0;
let velocityS = 0;
let velocityA = 0;
let velocityD = 0;
let velocityUp = 0;

camera.addComponent({
    update() {
        const transform = camera.getComponentOfType(Transform);
        const rotation = transform.rotation;
       

        quat.identity(rotation);
        quat.rotateY(rotation, rotation, -MouseX*sensitivity);
        //quat.rotateX(rotation, rotation, -MouseY*sensitivity);

        // X+ (desno), X- (levo), Z+ (nazaj), Z- (naprej), Y+ (gor), Y- (dol)
        const vecCamera = camera.getComponentOfType(Transform).translation;
        const Refvector = [vecCamera[0], vecCamera[1], vecCamera[2]-5];
        
        
        const vectorCameraToRef = [Refvector[0] - transform.translation[0],
                                   Refvector[1] - transform.translation[1],
                                   Refvector[2] - transform.translation[2]];
        
        const CameraFrVector = getForwardVector(camera);

        const vectorCameraToForward = [CameraFrVector[0] - transform.translation[0],
                                       CameraFrVector[1] - transform.translation[1],
                                       CameraFrVector[2] - transform.translation[2]];

        

        // računa kot za koliko je kamera rotirana glede na začetno smer
        let angleBetween = AngleBetweenVectors(vectorCameraToRef, vectorCameraToForward);
        //console.log("Angle: " + angleBetween*(180/Math.PI));
        
        const vTd = [vecCamera[0] , 0, vecCamera[2] - 4];
        const distT = VectLenght(vTd);

        //za forward in backward
        let Xtravel = Math.sin(angleBetween)*(cameraSpeed);
        let Ytravel = Math.cos(angleBetween)*(cameraSpeed); 

        //za sideways
        let Xsideways = Math.sin(angleBetween + Math.PI/2)*(cameraSpeed*0.6);
        if (angleBetween*(180/Math.PI) < 0) {
            Xsideways = -Xsideways;
        }
        let Ysideways = Math.cos(angleBetween + Math.PI/2)*(cameraSpeed*0.6);
        if (angleBetween*(180/Math.PI) < 0) {
            Ysideways = -Ysideways;
        }
        
        
        if(distT < 6 && vecCamera[2] < 4 && vecCamera[2] > 3  && (dooropened === false)){
            console.log("not pass");
            if(vecCamera[2] + Ytravel > 3.5 && vecCamera[2] + Ysideways > 3.5 && (angleBetween*(180/Math.PI) > 50 || angleBetween*(180/Math.PI) < -50)){
                Ytravel = 0;
                Ysideways = 0;
            }
        }
        

        let velocityFactor = 0.025
        

        // tranlation[0] -> x axis
        // tranlation[1] -> y axis
        // tranlation[2] -> z axis
        if (keysPressed['w'] || keysPressed['W']) {
           velocityW = 1;
           velocityS = 0;
        }
        transform.translation[0] -= Xtravel * velocityW;
        transform.translation[2] -= Ytravel * velocityW;

        if (keysPressed['s'] || keysPressed['S']) {
            velocityS = 1;
            velocityW = 0;
        }
        transform.translation[0] += Xtravel * velocityS;
        transform.translation[2] += Ytravel * velocityS;

        if (keysPressed['a'] || keysPressed['A']) {
            velocityA = 0.7;
            velocityD = 0;
        }
            if(angleBetween*(180/Math.PI) < 0) {
            transform.translation[0] += Xsideways * velocityA;
            transform.translation[2] += Ysideways * velocityA;
            } else {
            transform.translation[0] -= Xsideways * velocityA;
            transform.translation[2] -= Ysideways * velocityA;
            }
        if (keysPressed['d'] || keysPressed['D']) {
            velocityD = 0.7;
            velocityA = 0;
        }
            if(angleBetween*(180/Math.PI) < 0) {
            transform.translation[0] -= Xsideways * velocityD;
            transform.translation[2] -= Ysideways * velocityD;
            } else {
            transform.translation[0] += Xsideways * velocityD;
            transform.translation[2] += Ysideways * velocityD;
            }

        if (keysPressed[' ']) { 
            if(camera.getComponentOfType(Transform).translation[1] <= cameraDeafultZ){
            velocityUp = 0.3;
            }
        }
            transform.translation[1] += velocityUp;
        
            /*
        if (keysPressed['Shift']) { 
            //transform.translation[1] -= 1;
        }
        */
        

        velocityW -= velocityFactor;
        if (velocityW < 0) velocityW = 0;
        velocityS -= velocityFactor;
        if (velocityS < 0) velocityS = 0;
        velocityA -= velocityFactor;
        if (velocityA < 0) velocityA = 0;
        velocityD -= velocityFactor;
        if (velocityD < 0) velocityD = 0;

        velocityUp -= velocityFactor*0.7;
        if (velocityUp < 0 && camera.getComponentOfType(Transform).translation[1] <= cameraDeafultZ) {
            velocityUp = 0;
            camera.getComponentOfType(Transform).translation[1] = cameraDeafultZ;
        } 

        //console.log("x:" + transform.translation[0] + " z:" + transform.translation[1] + " y:" + transform.translation[2]);
    }
});

let targetCornerIndex = 23;
let targetCorner = cornerCordinates[targetCornerIndex];
const MonkeySpeed = 0.05;
let distToCorner = 10;

Monkey.returnNode().addComponent({
    update(){
        const MonkeyTransform = Monkey.returnNode().getComponentOfType(Transform);
        const rotation = MonkeyTransform.rotation;

        const CameraPos = camera.getComponentOfType(Transform).translation;
        const vectToPlayer = [CameraPos[0] - MonkeyTransform.translation[0], CameraPos[1] - MonkeyTransform.translation[1], CameraPos[2] - MonkeyTransform.translation[2]];
        const distToPlyr = VectLenght(vectToPlayer);

        const pointUP = [MonkeyTransform.translation[0], MonkeyTransform.translation[1], MonkeyTransform.translation[2]-5];
        const vectUP = [pointUP[0] - MonkeyTransform.translation[0], pointUP[1] - MonkeyTransform.translation[1], pointUP[2] - MonkeyTransform.translation[2]];
        if (distToPlyr<2){
            window.showLoseScreen();
        }
        if(distToCorner<=0.05){
            
            const pointDOWN = [MonkeyTransform.translation[0], MonkeyTransform.translation[1], MonkeyTransform.translation[2]+5];
            const pointLEFT = [MonkeyTransform.translation[0]-5, MonkeyTransform.translation[1], MonkeyTransform.translation[2]];
            const pointRIGHT = [MonkeyTransform.translation[0]+5, MonkeyTransform.translation[1], MonkeyTransform.translation[2]];
            const vectDOWN = [pointDOWN[0] - MonkeyTransform.translation[0], pointDOWN[1] - MonkeyTransform.translation[1], pointDOWN[2] - MonkeyTransform.translation[2]];
            const vectLEFT = [pointLEFT[0] - MonkeyTransform.translation[0], pointLEFT[1] - MonkeyTransform.translation[1], pointLEFT[2] - MonkeyTransform.translation[2]];
            const vectRIGHT = [pointRIGHT[0] - MonkeyTransform.translation[0], pointRIGHT[1] - MonkeyTransform.translation[1], pointRIGHT[2] - MonkeyTransform.translation[2]];

            let angleToUP = AngleBetweenVectors(vectToPlayer, vectUP);
            let angleToDOWN = AngleBetweenVectors(vectToPlayer, vectDOWN);
            let angleToLEFT = AngleBetweenVectors(vectToPlayer, vectLEFT);
            let angleToRIGHT = AngleBetweenVectors(vectToPlayer, vectRIGHT);

            if(Corners[targetCornerIndex][0] == null) angleToUP = 999;
            if(Corners[targetCornerIndex][1] == null) angleToDOWN = 999;
            if(Corners[targetCornerIndex][2] == null) angleToLEFT = 999;
            if(Corners[targetCornerIndex][3] == null) angleToRIGHT = 999;

            let minAngle = Math.min(Math.abs(angleToUP), Math.abs(angleToDOWN), Math.abs(angleToLEFT), Math.abs(angleToRIGHT));

            if(minAngle === Math.abs(angleToUP)){
                targetCornerIndex = Corners[targetCornerIndex][0];
                targetCorner = cornerCordinates[targetCornerIndex];

            }else if(minAngle === Math.abs(angleToDOWN)){
                targetCornerIndex = Corners[targetCornerIndex][1];
                targetCorner = cornerCordinates[targetCornerIndex];

            }else if(minAngle === Math.abs(angleToLEFT)){
                targetCornerIndex = Corners[targetCornerIndex][2];
                targetCorner = cornerCordinates[targetCornerIndex];

            }else if(minAngle === Math.abs(angleToRIGHT)){
                targetCornerIndex = Corners[targetCornerIndex][3];
                targetCorner = cornerCordinates[targetCornerIndex];

            }
        }

        const vectToCorner = [targetCorner[0] - MonkeyTransform.translation[0], targetCorner[1] - MonkeyTransform.translation[1], targetCorner[2] - MonkeyTransform.translation[2]];
        distToCorner = VectLenght(vectToCorner);

        let angleToCorner = AngleBetweenVectors(vectToCorner, vectUP);
        console.log("pos: x:" + MonkeyTransform.translation[0] + " z:" + MonkeyTransform.translation[1] + " y:" + MonkeyTransform.translation[2]);
        console.log("dist to corner: " + distToCorner + " corner index: " + targetCornerIndex);

        let MonkeyXtravel = Math.sin(angleToCorner)*(MonkeySpeed);
        let MonkeyYtravel = Math.cos(angleToCorner)*(MonkeySpeed); 
        

        MonkeyTransform.translation[0] += MonkeyXtravel;
        MonkeyTransform.translation[2] -= MonkeyYtravel;
    }
});
let Srot = 0;
for (let k = 0; k < shrdArray.length; k++) {
    shrdArray[k].returnNode().addComponent({
        update(){
            if(shards[k][1] === false) return;
            const ShardTransform = shrdArray[k].returnNode().getComponentOfType(Transform).translation;
            const CameraPos2 = camera.getComponentOfType(Transform).translation;
            const vectToPlayer2 = [CameraPos2[0] - ShardTransform[0], 0, CameraPos2[2] - ShardTransform[2]];
            const distToPlyr2 = VectLenght(vectToPlayer2);

            const ShardT = shrdArray[k].returnNode().getComponentOfType(Transform);
            const ShardRotation = ShardT.rotation;
            quat.identity(ShardRotation);
            quat.rotateY(ShardRotation, ShardRotation, Srot+=0.001);

            if(distToPlyr2 < 2){
                shards[k][1] = false;
                shardsCollected++;
                if (hud) hud.textContent = `Shards: ${shardsCollected}/${shardNum}`;
                if (shardsCollected === shardNum) {
                    if (hud) hud.textContent = `Shards: ${shardsCollected}/${shardNum}  Go to the doors!`;
                    //window.showWinScreen(); 
                }
            }
        }
    });
}

let doorOpen = false;

door.returnNode().addComponent({
    update(){
        const doorTransform = door.returnNode().getComponentOfType(Transform).translation;
        const CameraPos3 = camera.getComponentOfType(Transform).translation;
        const vectToPlayer3 = [CameraPos3[0] - doorTransform[0], 0, CameraPos3[2] - doorTransform[2]];
        const distToPlyr3 = VectLenght(vectToPlayer3);

        if(distToPlyr3 < 5 && shardsCollected === shardNum && (keysPressed['e'] || keysPressed['E'])){
            doorOpen = true;
            collisions.removeWall(meta => meta.type === 'door-wall');
        }
        if(doorTransform[0] > -2.25 && doorOpen === true){
            doorTransform[0] -= 0.01;
        }
        if(doorTransform[0] >= -2.25 || doorTransform[0] <= -2.20){
            dooropened = true;
        }
    }
});

door2.returnNode().addComponent({
    update(){
        const door2Transform = door2.returnNode().getComponentOfType(Transform).translation;
        const CameraPos4 = camera.getComponentOfType(Transform).translation;
        const vectToPlayer4 = [CameraPos4[0] - door2Transform[0], 0, CameraPos4[2] - door2Transform[2]];
        const distToPlyr4 = VectLenght(vectToPlayer4);

        if(distToPlyr4 < 5 && shardsCollected === shardNum && (keysPressed['e'] || keysPressed['E'])){
            doorOpen = true;
            collisions.removeWall(meta => meta.type === 'door-wall');
        }
        if(door2Transform[0] < 2.25 && doorOpen === true){
            door2Transform[0] += 0.01;
        }
        if(door2Transform[0] >= 2.20 || door2Transform[0] <= 2.25){
            dooropened = true;
        }
    }
});

window.addEventListener('keydown', (e) => {
    const key = e.key.length === 1 ? e.key.toLowerCase() : e.key;
    keysPressed[key] = true;
});

window.addEventListener('keyup', (e) => {
    const key = e.key.length === 1 ? e.key.toLowerCase() : e.key;
    keysPressed[key] = false;
});

window.addEventListener('blur', () => {
    for (const key in keysPressed) keysPressed[key] = false;
});


const scene = new Node(); // ----------------------------------------------------------
scene.addChild(ground);
/*
scene.addChild(wall1.returnNode());
scene.addChild(wall2.returnNode());
scene.addChild(wall3.returnNode());
scene.addChild(wall4.returnNode());
*/

scene.addChild(Monkey.returnNode());

scene.addChild(shard.returnNode());

scene.addChild(door.returnNode());
scene.addChild(door2.returnNode());

for(let k=0; k<shrdArray.length; k++) {
    scene.addChild(shrdArray[k].returnNode());
}

for (let j=0; j<wallsArray.length; j++) {
    scene.addChild(wallsArray[j].returnNode());
}

scene.addChild(camera);

// Update all components
function update() {
    scene.traverse(node => {
        for (const component of node.components) {
            component.update?.();
        }
    });
}

function render() {
    // Get the required matrices
    const modelMatrix = getGlobalModelMatrix(ground);
    const viewMatrix = getGlobalViewMatrix(camera);
    const projectionMatrix = getProjectionMatrix(camera);

    // Upload the transformation matrix
    const mvp = mat4.create()
        .multiply(projectionMatrix)
        .multiply(viewMatrix)
        .multiply(modelMatrix);

    const cameraPos = camera.getComponentOfType(Transform).translation;

    const uniformData = buildUniformData({
      mvp,
      model: modelMatrix,
      cameraPos,
      lightingState
    });

    device.queue.writeBuffer(uniformBuffer, 0, uniformData);

    /*
    wall1.updateRender();
    wall2.updateRender();
    wall3.updateRender();
    wall4.updateRender();
    */

    Monkey.updateRender();

    shard.updateRender();
    
    door.updateRender();
    door2.updateRender();
    
    for (let k=0; k<shrdArray.length; k++) {
        if(shards[k][1] === true){
            shrdArray[k].updateRender();
        }
    }
    
    for (let j=0; j<wallsArray.length; j++) {
        wallsArray[j].updateRender();
    }
    

    // Render
    const commandEncoder = device.createCommandEncoder();
    const renderPass = commandEncoder.beginRenderPass({
        colorAttachments: [{
            view: context.getCurrentTexture().createView(),
            loadOp: 'clear',
            clearValue: [0.7, 0.8, 0.9, 1],
            storeOp: 'store',
        }],
        depthStencilAttachment: {
            view: depthTexture.createView(),
            depthClearValue: 1,
            depthLoadOp: 'clear',
            depthStoreOp: 'discard',
        },
    });
    renderPass.setPipeline(pipeline);
    renderPass.setVertexBuffer(0, vertexBuffer);
    renderPass.setIndexBuffer(indexBuffer, 'uint32');
    renderPass.setBindGroup(0, bindGroup);
    renderPass.drawIndexed(indices.length);
    // === DRAW CEILING ===
    renderPass.setVertexBuffer(0, ceilingVertexBuffer);
    renderPass.setBindGroup(0, ceilingBindGroup);
    renderPass.drawIndexed(indices.length);


    
    /*
    wall1.draw(renderPass);
    wall2.draw(renderPass);
    wall3.draw(renderPass);
    wall4.draw(renderPass);
    */
    Monkey.draw(renderPass);

    shard.draw(renderPass);
    
    door.draw(renderPass);
    door2.draw(renderPass);
    
    for (let j=0; j<wallsArray.length; j++) {
        wallsArray[j].draw(renderPass);
    }

    for (let k=0; k<shrdArray.length; k++) {
        if(shards[k][1] === true){
            shrdArray[k].draw(renderPass);
        }
    }
    
    for (let i = 0; i < lamps.length; i++) {
        const L = lamps[i];

        const model = mat4.create()
            .translate(L.pos)
            .scale([lampSize, lampHeight, lampSize]);

        const mvp = mat4.create()
            .multiply(projectionMatrix)
            .multiply(viewMatrix)
            .multiply(model);

        const u = new Float32Array(20);
        u.set(mvp, 0);
        u.set(L.color, 16);

        device.queue.writeBuffer(lampUniformBuffers[i], 0, u);

        renderPass.setPipeline(lampPipeline);
        renderPass.setBindGroup(0, lampBindGroups[i]);
        renderPass.setVertexBuffer(0, lampMesh.vertexBuffer);
        renderPass.setIndexBuffer(lampMesh.indexBuffer, "uint16");
        renderPass.drawIndexed(lampMesh.indexCount);
    }


    renderPass.end();
    device.queue.submit([commandEncoder.finish()]);

    
}

const wallColliders = [
    { 
        // wall1 (rotation 1 in main.js) = Side wall on the right
        node: { translation: [30, 7.5, 0] }, 
        size: [1, 25, 60], 
        meta: { type: 'wall' } 
    },
    { 
        // wall2 (rotation 1 in main.js) = Side wall on the left
        // position [-60, 0, 0] + vertex offset [30, 0, 0] = -30
        node: { translation: [-30, 7.5, 0] }, 
        size: [1, 25, 60], 
        meta: { type: 'wall' } 
    },
    { 
        // wall3 (rotation 0 in main.js) = Back wall
        node: { translation: [0, 7.5, -30] }, 
        size: [60, 25, 1], 
        meta: { type: 'wall' } 
    },
    { 
        // wall4 (rotation 0 in main.js) = Back wall
        node: { translation: [0, 7.5, 30] }, 
        size: [60, 25, 1], 
        meta: { type: 'wall' } 
    },


    { 
        // This is wall 39 from Positions.js: { pos: [0, 0, 4], size: [8, 25, 1], rotation: 0 }
        node: { translation: [0, 0, 4] }, 
        size: [8, 25, 1], 
        meta: { type: 'door-wall' } // Add this label
    },

    // ADD THESE: The physical boxes for the doors
    // Because we use door.node, the collision moves with your animation!
    { 
        node: door.node, 
        size: [1.5, 9, 0.4], 
        meta: { type: 'door-panel' } 
    },

    { 
        node: door2.node, 
        size: [1.5, 9, 0.4], 
        meta: { type: 'door-panel' } 
    }
];  

for (const w of walls) {
    wallColliders.push({
        node: { translation: w.pos },
        size: w.size,
        meta: { type: "wall" }
    });
}
  

const collisions = new Collisions({
    playerNode: camera,
    playerSize: [1, 6, 1],
    wallColliders
});


function frame() {
    update();
    collisions.update();
    render();
    requestAnimationFrame(frame);
}

requestAnimationFrame(frame);
