export const corners = [
    { c1: 25, c2: null, c3: null, c4: null },   //0
    { c1: 11, c2: null, c3: 2, c4: 25 },        //1
    { c1: null, c2: 3, c3: null, c4: 1 },   //2
    { c1: 2, c2: null, c3: 4, c4: 23 },        //3
    { c1: null, c2: 21, c3: 5, c4: 3 },        //4
    { c1: 6, c2: null, c3: null, c4: 4 },    //5
    { c1: null, c2: 5, c3: 7, c4: null },   //6
    { c1: 8, c2: null, c3: null, c4: 6 },   //7
    { c1: 9, c2: 7, c3: null, c4: 11 },     //8
    { c1: null, c2: 8, c3: null, c4: 10 },  //9
    { c1: null, c2: 11, c3: 9, c4: 12 },    //10
    { c1: 10, c2: 1, c3: 8, c4: null },     //11
    { c1: null, c2: 13, c3: 10, c4: null }, //12
    { c1: 12, c2: null, c3: 14, c4: null }, //13
    { c1: null, c2: 15, c3: null, c4: 13 }, //14
    { c1: 14, c2: 16, c3: 25, c4: null },    //15
    { c1: 15, c2: 24, c3: null, c4: 17 },   //16
    { c1: null, c2: 18, c3: 16, c4: null }, //17
    { c1: 17, c2: null, c3: 19, c4: null }, //18
    { c1: null, c2: 20, c3: 22, c4: 18 },   //19
    { c1: 19, c2: null, c3: 21, c4: null }, //20
    { c1: 4, c2: null, c3: null, c4: 20 },  //21
    { c1: 23, c2: null, c3: null, c4: 19 }, //22
    { c1: null, c2: 22, c3: 3, c4: 24 },    //23
    { c1: 16, c2: null, c3: 23, c4: null }, //24
    { c1: null, c2: 0, c3: 1, c4: 15 },     //25
];


