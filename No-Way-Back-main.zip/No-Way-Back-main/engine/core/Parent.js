export class Parent {

    constructor(entity) {
        this.entity = entity;
    }

}
